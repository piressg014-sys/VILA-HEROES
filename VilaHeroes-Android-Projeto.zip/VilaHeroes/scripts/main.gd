extends Node3D

const SAVE_PATH := "user://vila_heroes_save.json"
var gold := 2500
var elixir := 1800
var selected: Dictionary = {}
var buildings: Array[Dictionary] = []
var camera: Camera3D
var ui_layer: CanvasLayer
var gold_label: Label
var elixir_label: Label
var info_label: Label
var upgrade_button: Button
var toast_label: Label
var drag_start := Vector2.ZERO
var last_touch := Vector2.ZERO
var dragging := false
var pinch_distance := 0.0
var camera_target := Vector3.ZERO
var camera_distance := 21.0
var build_timer := 0.0
var build_remaining := 0.0
var build_target: Dictionary = {}
var ambient_time := 0.0

func _ready() -> void:
	_build_world()
	_build_camera()
	_build_ui()
	_load_game()
	_update_ui()
	var timer := Timer.new()
	timer.wait_time = 1.0
	timer.timeout.connect(_on_tick)
	add_child(timer)
	timer.start()

func _process(delta: float) -> void:
	ambient_time += delta
	for n in get_tree().get_nodes_in_group("sway"):
		if is_instance_valid(n):
			n.rotation.z = sin(ambient_time * 1.4 + float(n.get_meta("phase", 0.0))) * 0.075
	for n in get_tree().get_nodes_in_group("smoke"):
		if is_instance_valid(n):
			n.position.y = 2.35 + sin(ambient_time * 1.7 + float(n.get_meta("phase", 0.0))) * 0.12
			n.scale = Vector3.ONE * (0.75 + (sin(ambient_time * 1.2) + 1.0) * 0.12)

func _build_world() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("3976a8")
	sky_mat.sky_horizon_color = Color("b9e5ef")
	sky_mat.ground_bottom_color = Color("4c713e")
	sky_mat.ground_horizon_color = Color("a4c77c")
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("d7edff")
	env.ambient_light_energy = 0.75
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_env.environment = env
	add_child(world_env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -32, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)

	_add_box("Island", Vector3(0, -0.55, 0), Vector3(25, 1.0, 21), Color("78bd55"), false, 0)
	_add_box("GrassTop", Vector3(0, -0.015, 0), Vector3(24.7, 0.12, 20.7), Color("8bd35e"), false, 0)
	# Warm stone paths form a welcoming central plaza.
	_add_box("MainPath", Vector3(0, 0.055, 0.6), Vector3(3.2, 0.10, 17.0), Color("d9bd8b"), false, 0)
	_add_box("CrossPath", Vector3(0, 0.06, 0.5), Vector3(19.0, 0.11, 2.6), Color("e3c99a"), false, 0)
	for i in range(8):
		_add_box("PathStone", Vector3(-1.05 + (i % 2) * 0.5, 0.13, -7.0 + i * 1.9), Vector3(0.42, 0.035, 0.55), Color("f0d9b0"), false, 0)

	# Main village buildings, placed around the plaza.
	_add_building("Centro da Vila", "townhall", Vector3(0, 0, -1.0), 1)
	_add_building("Mina de Ouro", "gold", Vector3(-6.2, 0, -4.5), 1)
	_add_building("Coletor de Elixir", "elixir", Vector3(6.2, 0, -4.5), 1)
	_add_building("Quartel", "barracks", Vector3(-6.2, 0, 3.9), 1)
	_add_building("Torre de Arqueiras", "tower", Vector3(6.2, 0, 3.9), 1)
	_add_building("Armazém de Ouro", "storage", Vector3(-9.1, 0, 0.0), 1)
	_add_building("Armazém de Elixir", "elixir_storage", Vector3(9.1, 0, 0.0), 1)
	_add_building("Cabana do Construtor", "hut", Vector3(0, 0, 7.0), 1)

	# Decorative trees, rocks, flowers, fences and animated flags.
	for p in [Vector3(-10,0,-7.5), Vector3(-9.8,0,6.8), Vector3(10,0,-7.3), Vector3(10,0,6.9), Vector3(-3.8,0,-8.3), Vector3(4.1,0,-8.0), Vector3(-3.8,0,8.2), Vector3(4.0,0,8.1)]:
		_add_tree(p)
	for i in range(18):
		var x := randf_range(-11.0, 11.0)
		var z := randf_range(-9.0, 9.0)
		if abs(x) > 8.2 or abs(z) > 7.5:
			_add_flower(Vector3(x, 0.06, z))
	for p in [Vector3(-11.0,0,-3),Vector3(11.0,0,3),Vector3(-8.5,0,8.3),Vector3(8.5,0,-8.3)]:
		_add_rock(p)
	_add_flag(Vector3(-2.6,0,-1.0), Color("e95b4d"))
	_add_flag(Vector3(2.6,0,-1.0), Color("438be0"))
	_add_fountain(Vector3(0,0,4.4))
	_add_birds()

func _mat(color: Color, roughness := 0.85, metallic := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _mesh(parent: Node3D, mesh: Mesh, pos: Vector3, material: Material, scale_v := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.scale = scale_v
	mi.material_override = material
	parent.add_child(mi)
	return mi

func _box_mesh(size: Vector3) -> BoxMesh:
	var m := BoxMesh.new()
	m.size = size
	return m

func _sphere_mesh(radius: float) -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = radius
	m.height = radius * 2.0
	m.radial_segments = 12
	m.rings = 8
	return m

func _cylinder_mesh(top: float, bottom: float, height: float) -> CylinderMesh:
	var m := CylinderMesh.new()
	m.top_radius = top
	m.bottom_radius = bottom
	m.height = height
	m.radial_segments = 12
	return m

func _add_box(n: String, pos: Vector3, size: Vector3, color: Color, collider := false, group := 0) -> Node3D:
	var root := Node3D.new()
	root.name = n
	root.position = pos
	add_child(root)
	_mesh(root, _box_mesh(size), Vector3.ZERO, _mat(color))
	if collider:
		var body := StaticBody3D.new()
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = size
		shape.shape = box
		body.add_child(shape)
		root.add_child(body)
	return root

func _add_building(title: String, kind: String, pos: Vector3, level: int) -> void:
	var root := Node3D.new()
	root.name = kind + "_" + str(buildings.size())
	root.position = pos
	root.add_to_group("building_visual")
	add_child(root)
	var base_color := Color("e8d6ad")
	var wall_color := Color("e8c88e")
	var roof_color := Color("b84e3f")
	var h := 1.55
	match kind:
		"townhall":
			wall_color = Color("f0d7a4"); roof_color = Color("a94438"); h = 2.15
		"gold":
			wall_color = Color("a88b62"); roof_color = Color("6e5841")
		"elixir":
			wall_color = Color("c9b0e8"); roof_color = Color("7749b9")
		"barracks":
			wall_color = Color("d7a36b"); roof_color = Color("a84438")
		"tower":
			wall_color = Color("d7d0bd"); roof_color = Color("4778a9"); h = 2.35
		"storage":
			wall_color = Color("e5c16a"); roof_color = Color("8d633d")
		"elixir_storage":
			wall_color = Color("d0a2e8"); roof_color = Color("7749b9")
		"hut":
			wall_color = Color("e0b77c"); roof_color = Color("6f9a48")
	_mesh(root, _box_mesh(Vector3(2.15, 0.22, 1.9)), Vector3(0,0.14,0), _mat(Color("9a704b")))
	_mesh(root, _box_mesh(Vector3(1.85, h, 1.62)), Vector3(0,h*0.5+0.23,0), _mat(wall_color))
	# Roof made of two overlapping pitched slabs for a friendly toy-like silhouette.
	var roof := _mesh(root, _box_mesh(Vector3(2.2,0.22,1.95)), Vector3(0,h+0.42,0), _mat(roof_color))
	roof.rotation.z = -0.06
	_mesh(root, _box_mesh(Vector3(0.24,0.22,2.05)), Vector3(0,h+0.57,0), _mat(roof_color))
	_mesh(root, _box_mesh(Vector3(0.52,0.9,0.12)), Vector3(0,0.68,0.82), _mat(Color("75452e")))
	_mesh(root, _sphere_mesh(0.17), Vector3(0.28,0.78,0.9), _mat(Color("f4d16b"),0.35,0.5))
	# Window pair and timber details.
	for x in [-0.58,0.58]:
		_mesh(root, _box_mesh(Vector3(0.28,0.38,0.08)), Vector3(x,1.05,0.83), _mat(Color("77b9d6"),0.3))
		_mesh(root, _box_mesh(Vector3(0.34,0.07,0.10)), Vector3(x,1.05,0.9), _mat(Color("815437")))
	if kind == "townhall":
		_mesh(root, _cylinder_mesh(0.0,0.12,0.8), Vector3(0, h+0.95,0), _mat(Color("d8b65d")))
		_mesh(root, _sphere_mesh(0.22), Vector3(0,h+1.38,0), _mat(Color("e7c66b"),0.3,0.4))
	elif kind == "gold":
		for i in range(3):
			var nugget := _mesh(root, _sphere_mesh(0.28), Vector3(-0.48+i*0.48,0.45,0.98), _mat(Color("f6c644"),0.45,0.2))
			nugget.scale = Vector3(1.0,0.65,0.8)
	elif kind == "elixir" or kind == "elixir_storage":
		_mesh(root, _cylinder_mesh(0.48,0.48,1.2), Vector3(0,0.85,0.98), _mat(Color("b85be0"),0.25,0.2))
	elif kind == "tower":
		_mesh(root, _cylinder_mesh(0.85,0.65,0.35), Vector3(0,h+0.58,0), _mat(Color("d2c8b0")))
		_mesh(root, _cylinder_mesh(0.12,0.12,0.8), Vector3(0,h+0.96,0), _mat(Color("684a36")))
	# A little chimney and animated puff on each major building.
	var chimney := _mesh(root, _box_mesh(Vector3(0.28,0.65,0.3)), Vector3(0.65,h+0.2,-0.35), _mat(Color("9d5546")))
	var puff := _mesh(root, _sphere_mesh(0.16), Vector3(0.65,h+0.65,-0.35), _mat(Color(0.92,0.94,0.96,0.55)))
	puff.add_to_group("smoke")
	puff.set_meta("phase", randf()*6.0)
	# Collider for tap selection.
	var body := StaticBody3D.new()
	body.name = "TapTarget"
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.5, h+1.0, 2.3)
	col.shape = shape
	col.position.y = (h+0.5)*0.5
	body.add_child(col)
	root.add_child(body)
	var data := {"title":title,"kind":kind,"level":level,"node":root,"busy":false,"progress":0.0}
	buildings.append(data)

func _add_tree(pos: Vector3) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	_mesh(root,_cylinder_mesh(0.18,0.27,1.1),Vector3(0,0.55,0),_mat(Color("805337")))
	var crown := _mesh(root,_sphere_mesh(0.82),Vector3(0,1.45,0),_mat(Color("3f984b")))
	crown.scale = Vector3(1.0,1.08,0.9)
	var crown2 := _mesh(root,_sphere_mesh(0.55),Vector3(0.42,1.85,0.05),_mat(Color("59b957")))
	crown2.add_to_group("sway")
	crown2.set_meta("phase",randf()*6.0)
	_mesh(root,_sphere_mesh(0.35),Vector3(-0.42,1.72,0.08),_mat(Color("74c95d")))

func _add_flower(pos: Vector3) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	_mesh(root,_cylinder_mesh(0.025,0.025,0.25),Vector3(0,0.12,0),_mat(Color("438c42")))
	var colors := [Color("f5df6b"),Color("f08c9a"),Color("ffffff"),Color("9c83e8")]
	_mesh(root,_sphere_mesh(0.12),Vector3(0,0.29,0),_mat(colors[randi()%colors.size()]))

func _add_rock(pos: Vector3) -> void:
	var r := _mesh(self,_sphere_mesh(0.55),pos+Vector3(0,0.25,0),_mat(Color("9b9e98")))
	r.scale = Vector3(1.25,0.72,0.9)

func _add_flag(pos: Vector3, color: Color) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	_mesh(root,_cylinder_mesh(0.035,0.05,2.1),Vector3(0,1.05,0),_mat(Color("805a38")))
	var flag := _mesh(root,_box_mesh(Vector3(0.95,0.58,0.06)),Vector3(0.48,1.78,0),_mat(color))
	flag.add_to_group("sway")
	flag.set_meta("phase",randf()*6.0)
	_mesh(root,_sphere_mesh(0.10),Vector3(0,2.14,0),_mat(Color("f4d16b"),0.3,0.3))

func _add_fountain(pos: Vector3) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	_mesh(root,_cylinder_mesh(1.0,1.0,0.25),Vector3(0,0.15,0),_mat(Color("b6b6a8")))
	_mesh(root,_cylinder_mesh(0.72,0.72,0.12),Vector3(0,0.31,0),_mat(Color("64bfe0"),0.2,0.1))
	_mesh(root,_cylinder_mesh(0.16,0.25,0.65),Vector3(0,0.62,0),_mat(Color("c6c9c4")))
	var water := _mesh(root,_sphere_mesh(0.12),Vector3(0,1.0,0),_mat(Color(0.66,0.91,0.95,0.8)))
	water.add_to_group("sway")
	water.set_meta("phase",0.5)

func _add_birds() -> void:
	for i in range(3):
		var bird := Node3D.new()
		bird.position = Vector3(-5.0 + i*4.0, 5.0 + (i%2), -2.0 + i*1.5)
		add_child(bird)
		_mesh(bird,_sphere_mesh(0.10),Vector3.ZERO,_mat(Color("fff2d0")))
		var wing := _mesh(bird,_box_mesh(Vector3(0.42,0.035,0.12)),Vector3(0,0.03,0),_mat(Color("fff2d0")))
		wing.add_to_group("sway")
		wing.set_meta("phase",float(i))
		bird.set_meta("bird_phase",float(i)*2.0)

func _build_camera() -> void:
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 20.0
	camera.position = Vector3(15,19,20)
	camera_target = Vector3.ZERO
	camera.current = true
	add_child(camera)
	_update_camera()

func _update_camera() -> void:
	camera.position = camera_target + Vector3(camera_distance*0.72,camera_distance*0.92,camera_distance*0.92)
	camera.look_at(camera_target,Vector3.UP)

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(root)
	# Header resource capsule.
	var header := PanelContainer.new()
	header.position = Vector2(18,14)
	header.size = Vector2(470,66)
	_style_panel(header,Color(0.10,0.16,0.20,0.88))
	root.add_child(header)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation",18)
	header.add_child(row)
	gold_label = _make_label("🟡  2.500",22,Color("ffe28a"))
	elixir_label = _make_label("💜  1.800",22,Color("e3b8ff"))
	row.add_child(gold_label)
	row.add_child(elixir_label)
	var title := _make_label("VILA HEROES",24,Color("fff2ce"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.position = Vector2(0,88)
	title.size = Vector2(300,38)
	title.set_anchors_preset(Control.PRESET_CENTER_TOP)
	root.add_child(title)
	var subtitle := _make_label("Sua vila, sua lenda",13,Color("ffffff"))
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.position = Vector2(0,122)
	subtitle.size = Vector2(300,24)
	subtitle.set_anchors_preset(Control.PRESET_CENTER_TOP)
	root.add_child(subtitle)
	# Bottom action dock.
	var dock := PanelContainer.new()
	dock.anchor_left = 0.5
	dock.anchor_right = 0.5
	dock.anchor_top = 1.0
	dock.anchor_bottom = 1.0
	dock.offset_left = -310
	dock.offset_right = 310
	dock.offset_top = -88
	dock.offset_bottom = -12
	_style_panel(dock,Color(0.10,0.16,0.20,0.92))
	root.add_child(dock)
	var actions := HBoxContainer.new()
	actions.alignment = BoxContainer.ALIGNMENT_CENTER
	actions.add_theme_constant_override("separation",12)
	dock.add_child(actions)
	for pair in [["🏗  Construir","build"],["⚔  Exército","army"],["🛡  Defesa","defense"],["💾  Salvar","save"]]:
		var b := Button.new()
		b.text = pair[0]
		b.custom_minimum_size = Vector2(135,54)
		b.add_theme_font_size_override("font_size",17)
		b.pressed.connect(_on_action.bind(pair[1]))
		actions.add_child(b)
	# Selection / upgrade panel.
	var info_panel := PanelContainer.new()
	info_panel.anchor_left = 1.0
	info_panel.anchor_right = 1.0
	info_panel.anchor_top = 0.5
	info_panel.anchor_bottom = 0.5
	info_panel.offset_left = -265
	info_panel.offset_right = -16
	info_panel.offset_top = -85
	info_panel.offset_bottom = 95
	_style_panel(info_panel,Color(0.10,0.16,0.20,0.91))
	root.add_child(info_panel)
	var info_col := VBoxContainer.new()
	info_col.add_theme_constant_override("separation",8)
	info_panel.add_child(info_col)
	info_label = _make_label("Toque em uma construção\npara ver seus detalhes.",16,Color("fff2ce"))
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_col.add_child(info_label)
	upgrade_button = Button.new()
	upgrade_button.text = "Melhorar construção"
	upgrade_button.custom_minimum_size = Vector2(210,46)
	upgrade_button.pressed.connect(_upgrade_selected)
	upgrade_button.disabled = true
	info_col.add_child(upgrade_button)
	toast_label = _make_label("Arraste para explorar a vila",15,Color("ffffff"))
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.anchor_left = 0.5
	toast_label.anchor_right = 0.5
	toast_label.anchor_top = 1.0
	toast_label.anchor_bottom = 1.0
	toast_label.offset_left = -220
	toast_label.offset_right = 220
	toast_label.offset_top = -120
	toast_label.offset_bottom = -94
	root.add_child(toast_label)

func _make_label(txt: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",color)
	l.add_theme_color_override("font_shadow_color",Color(0,0,0,0.6))
	l.add_theme_constant_override("shadow_offset_x",2)
	l.add_theme_constant_override("shadow_offset_y",2)
	return l

func _style_panel(panel: PanelContainer, color: Color) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = 18
	style.corner_radius_top_right = 18
	style.corner_radius_bottom_left = 18
	style.corner_radius_bottom_right = 18
	style.border_width_left = 2
	style.border_width_right = 2
	style.border_width_top = 2
	style.border_width_bottom = 2
	style.border_color = Color(1,0.86,0.56,0.65)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	panel.add_theme_stylebox_override("panel",style)

func _on_tick() -> void:
	for b in buildings:
		match b.kind:
			"gold": gold += 8 * int(b.level)
			"elixir": elixir += 8 * int(b.level)
	if build_remaining > 0.0:
		build_remaining -= 1.0
		if build_remaining <= 0.0:
			build_target.level += 1
			build_target.busy = false
			_refresh_building(build_target)
			_toast("Evolução concluída: " + str(build_target.title))
			build_target = {}
	_update_ui()
	_save_game()

func _update_ui() -> void:
	if gold_label: gold_label.text = "🟡  " + _format_number(gold)
	if elixir_label: elixir_label.text = "💜  " + _format_number(elixir)
	if not selected.is_empty() and info_label:
		_show_selected()

func _format_number(n: int) -> String:
	var s := str(n)
	var out := ""
	for i in range(s.length()):
		out += s[i]
		if (s.length()-i-1) % 3 == 0 and i < s.length()-1: out += "."
	return out

func _show_selected() -> void:
	var b := selected
	info_label.text = str(b.title) + "\nNível " + str(b.level) + ("\nEm evolução..." if b.busy else "\nPronto para evoluir")
	upgrade_button.disabled = b.busy
	upgrade_button.text = "Melhorar • " + str(_upgrade_cost(b)) + " ouro"

func _upgrade_cost(b: Dictionary) -> int:
	return 250 * int(b.level) * int(b.level)

func _upgrade_selected() -> void:
	if selected.is_empty() or selected.busy: return
	var cost := _upgrade_cost(selected)
	if gold < cost:
		_toast("Ouro insuficiente! Colete mais na mina.")
		return
	gold -= cost
	selected.busy = true
	build_target = selected
	build_remaining = 12.0 + float(selected.level) * 8.0
	_toast("Obra iniciada! Toque em outra área para explorar.")
	_update_ui()
	_save_game()

func _refresh_building(b: Dictionary) -> void:
	var node: Node3D = b.node
	if not is_instance_valid(node): return
	# Upgrade accents grow with level; the model remains recognizable.
	var accent := node.get_node_or_null("LevelAccent")
	if accent: accent.queue_free()
	var a := _mesh(node,_sphere_mesh(0.16 + 0.025*float(b.level)),Vector3(0,2.8+0.12*float(b.level),0),_mat(Color("f7d45f"),0.3,0.25))
	a.name = "LevelAccent"

func _on_action(action: String) -> void:
	match action:
		"save":
			_save_game(); _toast("Progresso salvo!")
		"build": _toast("Selecione uma construção para evoluir.")
		"army": _toast("Quartel: treinamento de tropas chega na próxima atualização.")
		"defense": _toast("Toque na Torre de Arqueiras para consultar sua evolução.")

func _toast(msg: String) -> void:
	if toast_label: toast_label.text = msg

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			dragging = true
			drag_start = event.position
			last_touch = event.position
		else:
			dragging = false
			if drag_start.distance_to(event.position) < 14.0: _select_at(event.position)
	elif event is InputEventScreenDrag:
		if dragging:
			var delta := event.position - last_touch
			_pan_camera(delta)
			last_touch = event.position
	elif event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				dragging = true; drag_start = event.position; last_touch = event.position
			else:
				dragging = false
				if drag_start.distance_to(event.position) < 8.0: _select_at(event.position)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			camera_distance = max(13.0,camera_distance-1.2); _update_camera()
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			camera_distance = min(29.0,camera_distance+1.2); _update_camera()
	elif event is InputEventMouseMotion and dragging and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		var delta := event.position-last_touch
		_pan_camera(delta)
		last_touch = event.position

func _pan_camera(delta: Vector2) -> void:
	camera_target.x -= delta.x * camera_distance / 950.0
	camera_target.z -= delta.y * camera_distance / 950.0
	camera_target.x = clamp(camera_target.x,-7.0,7.0)
	camera_target.z = clamp(camera_target.z,-6.0,6.0)
	_update_camera()

func _select_at(screen_pos: Vector2) -> void:
	var from := camera.project_ray_origin(screen_pos)
	var to := from + camera.project_ray_normal(screen_pos) * 100.0
	var query := PhysicsRayQueryParameters3D.create(from,to)
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		selected = {}; info_label.text = "Toque em uma construção\npara ver seus detalhes."; upgrade_button.disabled = true
		return
	var node: Node = hit.collider
	while node and not node.is_in_group("building_visual"):
		node = node.get_parent()
	for b in buildings:
		if node == b.node:
			selected = b
			_show_selected()
			return

func _save_game() -> void:
	var data := {"gold":gold,"elixir":elixir,"levels":[]}
	for b in buildings: data.levels.append(int(b.level))
	var f := FileAccess.open(SAVE_PATH,FileAccess.WRITE)
	if f: f.store_string(JSON.stringify(data))

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH): return
	var f := FileAccess.open(SAVE_PATH,FileAccess.READ)
	if not f: return
	var parsed = JSON.parse_string(f.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY: return
	gold = int(parsed.get("gold",gold)); elixir = int(parsed.get("elixir",elixir))
	var levels: Array = parsed.get("levels",[])
	for i in range(min(levels.size(),buildings.size())):
		buildings[i].level = int(levels[i])
		if int(buildings[i].level) > 1: _refresh_building(buildings[i])
