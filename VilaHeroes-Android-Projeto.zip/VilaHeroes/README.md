# VILA HEROES — protótipo Android

Protótipo 3D de estratégia para Godot 4.4.1. A vila é criada proceduralmente pelo script: terreno, caminhos, centro da vila, mina de ouro, coletor de elixir, quartel, torre, depósitos, árvores, flores, pedras, bandeiras e fonte. Inclui câmera isométrica com arrasto/zoom, seleção de edifícios, evolução com custo e tempo, geração passiva de recursos e salvamento local.

## Gerar o APK

O APK não está incluído neste pacote porque a compilação Android precisa do Godot 4.4.1 com export templates e SDK Android. O workflow `.github/workflows/android.yml` faz essa compilação automaticamente no GitHub Actions.

1. Envie o conteúdo deste ZIP para um repositório GitHub.
2. Abra a aba **Actions**.
3. Execute **Build Vila Heroes Android APK** (ou faça push na branch `main`).
4. Quando terminar, abra a execução e baixe o artefato **Vila-Heroes-Android-APK**.
5. Extraia o APK e instale no Android. Talvez seja necessário permitir instalação pelo navegador/gerenciador de arquivos.

## Controles

- Toque em uma construção para selecioná-la.
- Use **Melhorar** para iniciar uma evolução (tempo de protótipo acelerado).
- Arraste o dedo para mover a câmera.
- No PC: botão esquerdo arrasta/seleciona; roda do mouse aproxima/afasta.
- Mina e coletor geram recursos automaticamente.
- O progresso é salvo em `user://vila_heroes_save.json`.

## Observação

Este é um protótipo jogável inicial com modelos 3D procedurais estilizados, não uma reprodução dos assets proprietários de Clash of Clans. Modelos, texturas PBR, efeitos de partículas mais elaborados, tropas e multiplayer podem ser acrescentados nas próximas versões.
